#include <cmath>
#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;

#include "channel.h"
#define pi 3.141592653589793
#define ofdmPeriod 1280
#define delayBound 101
#define pathGainNum 7
//#define pathGainNum 20
#define symbolNum 14*10
#define framePeriod ofdmPeriod*symbolNum


double tau[7] = {0e-9,30e-9,70e-9,90e-9,110e-9,190e-9,410e-9};
//double tau[20] = {0.00, 2.1700e-07,	5.1200e-07,	5.1400e-07,	5.1700e-07,	6.7400e-07,	8.8200e-07,	1.2300e-06,1.28700e-06,1.31100e-06,1.34900e-06,1.53300e-06,1.53500e-06,1.62200e-06,1.81800e-06,1.83600e-06,1.88400e-06,1.94300e-06,2.04800e-06,2.1400e-06};

double Ts = 1.00/15000/1024;

double Sinc(const double &val)
{
    if(val == 0)
        return 1.00000;
    else
        return (sin(pi*val))/(pi*val);
}

void readFile(const char* filename, complex<double>** buffer)
{
    FILE* infile;
    double temp;
    infile = fopen(filename, "r");
        
    for(int i=0; i<framePeriod; i++)
        buffer[i] = new complex<double> [pathGainNum];
        
    for(int i=0; i<framePeriod; i++)
    {
        for(int j=0; j<pathGainNum; j++)
        {
            fscanf(infile,"%le",&buffer[i][j].real());
            fscanf(infile,"%le",&buffer[i][j].imag());
        }
    }       
    fclose(infile);    
}

complex<double> **FastFading(complex<double> *nextSymbol, int numTxANT, int numRxANT)
{
    const int totalLen = ofdmPeriod;// The actual length of z (int)real(nextSymbol[0])
    const int signalLen = totalLen/numTxANT;// The length of the symbol
    static int symbolCount = 0;// Number of symbols having be transmitted
    static complex<double> *prevSymbol = new complex<double> [totalLen+1];
    static complex<double>*** pathGain = new complex<double>** [numTxANT*numRxANT];
    static complex<double>**  cirBuffer = new complex<double>* [numTxANT*numRxANT];
    static int* pos = new int [numTxANT*numRxANT];
    static bool isRead = 0;
    //static bool isNULL = 0;
    
    // Read the pathgain from files at the first use
    if(isRead == 0)
    {
        // Set the initial val of pos, and initialize the pathGain and cirBuffer
        for(int i=0; i<numTxANT*numRxANT; i++)
        {
            pos[i]=0;
            pathGain[i] = new complex<double>* [framePeriod];
            cirBuffer[i] = new complex<double> [delayBound];
            for(int j=0; j<delayBound; j++)
                cirBuffer[i][j] = 0;
        }
        
        if(numTxANT*numRxANT==1)
            readFile("pathGain_NLOS1.txt", pathGain[0]);
        else if(numTxANT*numRxANT==2)
        {
            readFile("pathGain_NLOS1.txt", pathGain[0]);
            readFile("pathGain_NLOS2.txt", pathGain[1]);
        }
        else if(numTxANT*numRxANT==4)
        {
            readFile("pathGain_NLOS1.txt", pathGain[0]);
            readFile("pathGain_NLOS2.txt", pathGain[1]);
            readFile("pathGain_NLOS3.txt", pathGain[2]);
            readFile("pathGain_NLOS4.txt", pathGain[3]);                
        } 
        isRead = 1;
        
        for(int i=0; i<totalLen+1; i++)
            prevSymbol[i] = nextSymbol[i];
            
        return 0;
    }

    complex<double> **r = new complex<double>* [numRxANT];    
    for(int i=0; i<numRxANT; i++)
    {
        r[i] = new complex<double> [signalLen +1];
        r[i][0] = signalLen;
        for(int j=0; j<signalLen; j++)
        {
            r[i][j] = 0;  
        }
    }

    for(int rx=0; rx<numRxANT; rx++)
    {
        for(int tx=0; tx<numTxANT; tx++)
        {    
            complex<double> rxSig;
            complex<double> gain;
            for(int ntime=1; ntime<=signalLen; ntime++)
            {        
                rxSig = 0;
                cirBuffer[tx*2+rx][pos[tx*2+rx]]=prevSymbol[tx*signalLen+ntime];
  
                // Account for multipath gain from the past to current.
                for(int ndelay=-delayBound+1; ndelay<delayBound; ndelay++)
                {
                    gain = 0;
                    // Influenced from the total gains ( pathGainNum )                
                    for(int ngain=0; ngain<pathGainNum; ngain++)
                    {
                        gain += pathGain[tx*2+rx][symbolCount*ofdmPeriod+(ntime-1)][ngain]*((complex<double>) Sinc((tau[ngain])/Ts-(double)ndelay) ); 
                        // For testing,
                        //if(ntime==1 && ndelay==-100)
                            //cout<<setprecision(14)<<ngain<<" "<<pathGain[tx*2+rx][symbolCount*ofdmPeriod+(ntime-1)][ngain]<<endl;                    
                    }
                    
                    if(ndelay>=0)
                    {
                        if(pos[tx*2+rx]-ndelay>=0)
                            rxSig += cirBuffer[tx*2+rx][pos[tx*2+rx]-ndelay]*gain;                        
                        else
                            rxSig += cirBuffer[tx*2+rx][delayBound+(pos[tx*2+rx]-ndelay)]*gain;
                    }
                    else
                    {
                        if(ntime-ndelay<=signalLen)
                            rxSig += prevSymbol[ntime-ndelay]*gain;
                        else
                        {
                            if(nextSymbol!=NULL)
                              rxSig += nextSymbol[ntime-ndelay-signalLen]*gain;                            
                        }
                    }
                }
 
                r[rx][ntime]+=rxSig;
                pos[tx*2+rx]++;
                if(pos[tx*2+rx]==delayBound)
                    pos[tx*2+rx] = pos[tx*2+rx]%delayBound;
            }
        }
    }
    
    symbolCount++;
    if(symbolCount==symbolNum)
        symbolCount=0;
    
    if(nextSymbol!=NULL)
    {
        for(int i=0; i<totalLen+1; i++)
            prevSymbol[i] = nextSymbol[i];
    }
    else
    {
        for(int i=0; i<totalLen+1; i++)
            prevSymbol[i] = 0;          
    }
    
    return r;
}

complex<double> **Dummy_2(complex<double> *z, int numTxANT, int numRxANT, int OFDMSymIdx)
{
   static complex<double> **r = NULL;
   static complex<double> **r2 = NULL;
   static int count = 0;

   if ((count&1) == 0)
   {
      if (OFDMSymIdx != 14)
      {
         const int signalLen = (int)real(z[0]);
         r = new complex<double>* [2];
         r[0] = new complex<double> [signalLen +1];
         r[1] = new complex<double> [signalLen +1];
         r[0][0] = signalLen; r[1][0] = signalLen;

         // No channel effect.
         for (int j=1;j<=signalLen;j++)
         {
            r[0][j] = z[j];
            r[1][j] = z[j];
         }
      }

      count ^= 1;
      return r2;
   }
   else
   {
      if (OFDMSymIdx != 14)
      {
         const int signalLen = (int)real(z[0]);
         r2 = new complex<double>* [2];
         r2[0] = new complex<double> [signalLen +1];
         r2[1] = new complex<double> [signalLen +1];
         r2[0][0] = signalLen; r2[1][0] = signalLen;

         // No channel effect.
         for (int j=1;j<=signalLen;j++)
         {
            r2[0][j] = z[j];
            r2[1][j] = z[j];
         }
      } 
      
      count ^= 1;
      return r;
   }
}
